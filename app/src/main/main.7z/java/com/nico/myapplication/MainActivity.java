package com.nico.myapplication;

import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NdefMessage;
import android.nfc.Tag;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {

	TextView text;
	NdefMessage[] messages;
	Intent intent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		text = new TextView(this);
		text.setText("So, no NFC then?");
		text.setTextSize(20);
		text.setBackgroundColor(Color.rgb(200, 200, 200));

		RelativeLayout layout = new RelativeLayout(this);
		RelativeLayout.LayoutParams textDetails = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.WRAP_CONTENT,
				RelativeLayout.LayoutParams.WRAP_CONTENT
		);

		textDetails.addRule(RelativeLayout.CENTER_HORIZONTAL);
		textDetails.addRule(RelativeLayout.CENTER_VERTICAL);

		layout.addView(text, textDetails);
		setContentView(layout);
	}

	@Override
	protected void onResume() {
		super.onResume();

		intent = getIntent();
		String action = intent.getAction();
		if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
			Parcelable[] messagesRaw = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
			NdefMessage ndefMessage = (NdefMessage) messagesRaw[0];
			NdefRecord ndefRecord = ndefMessage.getRecords()[0];

			String payload = new String(ndefRecord.getPayload());
			text.setText("Your message is:\n" + payload);
		}
	}
}
